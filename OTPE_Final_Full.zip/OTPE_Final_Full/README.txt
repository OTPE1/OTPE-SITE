# OTPE — One True Positive Energy (Pages‑Ready)

This folder is a complete OTPE site ready for GitHub Pages.

## Files
- `index.html` — homepage with unified description + teaser, symbol, QR
- `dad.html` — one‑tap read‑aloud quick check
- `crypto.html` — simple watch‑only crypto view
- `assets/OTPE_Symbol.png` + `assets/OTPE_Symbol.ico` — your icons
- `assets/OTPE_QR.png` — QR (placeholder to your future live link)
- `assets/site.css` / `assets/site.js` — styles + speech helper

## Publish on GitHub Pages
1. Create a repository (e.g., `OTPE-VESSLE`) on your GitHub account.
2. Upload **all files** in this folder to that repo (drag & drop).
3. Settings → Pages → Source: Deploy from branch → Branch `main` → Folder `/root` → Save.
4. Your live link: `https://OTPE1.github.io/OTPE-VESSLE/`
5. (Optional) Regenerate `assets/OTPE_QR.png` to point to your exact live link.

## Add to Home Screen (Android)
Open your live site in Chrome → 3 dots → Add to Home screen.

## Desktop Icon (Windows)
Create a shortcut to your live link → Properties → Change Icon → use `assets/OTPE_Symbol.ico`.
